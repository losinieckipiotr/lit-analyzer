export type LitHtmlAttributeModifier = "." | "?" | "@";
export declare const DIAGNOSTIC_SOURCE = "lit-plugin";
export declare const LIT_HTML_BOOLEAN_ATTRIBUTE_MODIFIER = "?";
export declare const LIT_HTML_EVENT_LISTENER_ATTRIBUTE_MODIFIER = "@";
export declare const LIT_HTML_PROP_ATTRIBUTE_MODIFIER = ".";
export declare const LIT_HTML_ATTRIBUTE_MODIFIERS: LitHtmlAttributeModifier[];
export declare const MAX_RUNNING_TIME_PER_OPERATION = 150;
export declare const TS_IGNORE_FLAG = "@ts-ignore";
export declare const VERSION = "2.0.3";
//# sourceMappingURL=constants.d.ts.map