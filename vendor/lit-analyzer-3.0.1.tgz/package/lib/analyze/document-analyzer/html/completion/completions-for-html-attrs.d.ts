import { LitAnalyzerContext } from "../../../lit-analyzer-context.js";
import { HtmlNode } from "../../../types/html-node/html-node-types.js";
import { LitCompletion } from "../../../types/lit-completion.js";
import { DocumentPositionContext } from "../../../util/get-position-context-in-document.js";
export declare function completionsForHtmlAttrs(htmlNode: HtmlNode, location: DocumentPositionContext, { htmlStore }: LitAnalyzerContext): LitCompletion[];
//# sourceMappingURL=completions-for-html-attrs.d.ts.map