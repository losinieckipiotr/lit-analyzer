import { SimpleType, SimpleTypeComparisonOptions } from "web-component-analyzer/simple-type.js";
import { RuleModuleContext } from "../../../analyze/types/rule/rule-module-context.js";
export declare function isAssignableToType({ typeA, typeB }: {
    typeA: SimpleType;
    typeB: SimpleType;
}, context: RuleModuleContext, options?: SimpleTypeComparisonOptions): boolean;
//# sourceMappingURL=is-assignable-to-type.d.ts.map