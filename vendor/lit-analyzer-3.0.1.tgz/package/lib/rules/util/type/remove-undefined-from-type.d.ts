import { SimpleType } from "web-component-analyzer/simple-type.js";
export declare function removeUndefinedFromType(type: SimpleType): SimpleType;
//# sourceMappingURL=remove-undefined-from-type.d.ts.map