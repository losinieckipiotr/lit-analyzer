import * as tsModule from "typescript";
import { Node, Program, Type, TypeChecker } from "typescript";
export type SimpleTypeModifierKind = "EXPORT" | "AMBIENT" | "PUBLIC" | "PRIVATE" | "PROTECTED" | "STATIC" | "READONLY" | "ABSTRACT" | "ASYNC" | "DEFAULT";
export declare enum SimpleTypeKind {
    STRING_LITERAL = "STRING_LITERAL",
    NUMBER_LITERAL = "NUMBER_LITERAL",
    BOOLEAN_LITERAL = "BOOLEAN_LITERAL",
    BIG_INT_LITERAL = "BIG_INT_LITERAL",
    ES_SYMBOL_UNIQUE = "ES_SYMBOL_UNIQUE",
    STRING = "STRING",
    NUMBER = "NUMBER",
    BOOLEAN = "BOOLEAN",
    BIG_INT = "BIG_INT",
    ES_SYMBOL = "ES_SYMBOL",
    NULL = "NULL",
    UNDEFINED = "UNDEFINED",
    VOID = "VOID",
    NEVER = "NEVER",
    ANY = "ANY",
    UNKNOWN = "UNKNOWN",
    ENUM = "ENUM",
    ENUM_MEMBER = "ENUM_MEMBER",
    NON_PRIMITIVE = "NON_PRIMITIVE",
    UNION = "UNION",
    INTERSECTION = "INTERSECTION",
    INTERFACE = "INTERFACE",
    OBJECT = "OBJECT",
    CLASS = "CLASS",
    FUNCTION = "FUNCTION",
    METHOD = "METHOD",
    GENERIC_ARGUMENTS = "GENERIC_ARGUMENTS",
    GENERIC_PARAMETER = "GENERIC_PARAMETER",
    ALIAS = "ALIAS",
    TUPLE = "TUPLE",
    ARRAY = "ARRAY",
    DATE = "DATE",
    PROMISE = "PROMISE"
}
export declare const PRIMITIVE_TYPE_KINDS: SimpleTypeKind[];
export interface SimpleTypeBase {
    kind: SimpleTypeKind;
    name?: string;
}
interface SimpleTypeBigIntLiteral extends SimpleTypeBase {
    kind: SimpleTypeKind.BIG_INT_LITERAL;
    value: bigint;
}
export interface SimpleTypeString extends SimpleTypeBase {
    kind: SimpleTypeKind.STRING;
}
export interface SimpleTypeStringLiteral extends SimpleTypeBase {
    kind: SimpleTypeKind.STRING_LITERAL;
    value: string;
}
export interface SimpleTypeNumberLiteral extends SimpleTypeBase {
    kind: SimpleTypeKind.NUMBER_LITERAL;
    value: number;
}
export interface SimpleTypeBooleanLiteral extends SimpleTypeBase {
    kind: SimpleTypeKind.BOOLEAN_LITERAL;
    value: boolean;
}
interface SimpleTypeNumber extends SimpleTypeBase {
    kind: SimpleTypeKind.NUMBER;
}
interface SimpleTypeBoolean extends SimpleTypeBase {
    kind: SimpleTypeKind.BOOLEAN;
}
interface SimpleTypeBigInt extends SimpleTypeBase {
    kind: SimpleTypeKind.BIG_INT;
}
interface SimpleTypeESSymbol extends SimpleTypeBase {
    kind: SimpleTypeKind.ES_SYMBOL;
}
interface SimpleTypeESSymbolUnique extends SimpleTypeBase {
    kind: SimpleTypeKind.ES_SYMBOL_UNIQUE;
    value: string;
}
interface SimpleTypeNull extends SimpleTypeBase {
    kind: SimpleTypeKind.NULL;
}
export interface SimpleTypeNever extends SimpleTypeBase {
    kind: SimpleTypeKind.NEVER;
}
interface SimpleTypeUndefined extends SimpleTypeBase {
    kind: SimpleTypeKind.UNDEFINED;
}
export interface SimpleTypeAny extends SimpleTypeBase {
    kind: SimpleTypeKind.ANY;
}
interface SimpleTypeUnknown extends SimpleTypeBase {
    kind: SimpleTypeKind.UNKNOWN;
}
interface SimpleTypeVoid extends SimpleTypeBase {
    kind: SimpleTypeKind.VOID;
}
interface SimpleTypeNonPrimitive extends SimpleTypeBase {
    kind: SimpleTypeKind.NON_PRIMITIVE;
}
export interface SimpleTypeTuple extends SimpleTypeBase {
    kind: SimpleTypeKind.TUPLE;
    members: SimpleTypeMember[];
    rest?: boolean;
}
interface SimpleTypeArray extends SimpleTypeBase {
    kind: SimpleTypeKind.ARRAY;
    type: SimpleType;
}
interface SimpleTypeMember {
    optional: boolean;
    type: SimpleType;
    modifiers?: SimpleTypeModifierKind[];
}
export interface SimpleTypeMemberNamed extends SimpleTypeMember {
    name: string;
}
export type SimpleTypeFunctionParameter = {
    name: string;
    type: SimpleType;
    optional: boolean;
    rest: boolean;
    initializer: boolean;
};
interface SimpleTypeFunction extends SimpleTypeBase {
    kind: SimpleTypeKind.FUNCTION;
    parameters?: SimpleTypeFunctionParameter[];
    typeParameters?: SimpleTypeGenericParameter[];
    returnType?: SimpleType;
}
interface SimpleTypeMethod extends SimpleTypeBase {
    kind: SimpleTypeKind.METHOD;
    parameters: SimpleTypeFunctionParameter[];
    typeParameters?: SimpleTypeGenericParameter[];
    returnType: SimpleType;
}
export interface SimpleTypeObjectTypeBase extends SimpleTypeBase {
    members?: SimpleTypeMemberNamed[];
    ctor?: SimpleTypeFunction;
    call?: SimpleTypeFunction;
    typeParameters?: SimpleTypeGenericParameter[];
    indexType?: {
        ["STRING"]?: SimpleType;
        ["NUMBER"]?: SimpleType;
    };
}
interface SimpleTypeInterface extends SimpleTypeObjectTypeBase {
    kind: SimpleTypeKind.INTERFACE;
}
interface SimpleTypeClass extends SimpleTypeObjectTypeBase {
    kind: SimpleTypeKind.CLASS;
}
export interface SimpleTypeObject extends SimpleTypeObjectTypeBase {
    kind: SimpleTypeKind.OBJECT;
}
export interface SimpleTypeUnion extends SimpleTypeBase {
    kind: SimpleTypeKind.UNION;
    types: SimpleType[];
}
export interface SimpleTypeIntersection extends SimpleTypeBase {
    kind: SimpleTypeKind.INTERSECTION;
    types: SimpleType[];
}
export interface SimpleTypeEnumMember extends SimpleTypeBase {
    kind: SimpleTypeKind.ENUM_MEMBER;
    fullName: string;
    name: string;
    type: SimpleTypePrimitive;
}
interface SimpleTypeEnum extends SimpleTypeBase {
    name: string;
    kind: SimpleTypeKind.ENUM;
    types: SimpleTypeEnumMember[];
}
interface SimpleTypeDate extends SimpleTypeBase {
    kind: SimpleTypeKind.DATE;
}
interface SimpleTypePromise extends SimpleTypeBase {
    kind: SimpleTypeKind.PROMISE;
    type: SimpleType;
}
export interface SimpleTypeAlias extends SimpleTypeBase {
    kind: SimpleTypeKind.ALIAS;
    name: string;
    target: SimpleType;
    typeParameters?: SimpleTypeGenericParameter[];
}
export interface SimpleTypeGenericParameter extends SimpleTypeBase {
    name: string;
    kind: SimpleTypeKind.GENERIC_PARAMETER;
    default?: SimpleType;
}
export interface SimpleTypeGenericArguments extends SimpleTypeBase {
    kind: SimpleTypeKind.GENERIC_ARGUMENTS;
    name?: undefined;
    target: SimpleType;
    typeArguments: SimpleType[];
}
export type SimpleTypeLiteral = SimpleTypeBigIntLiteral | SimpleTypeBooleanLiteral | SimpleTypeStringLiteral | SimpleTypeNumberLiteral | SimpleTypeESSymbolUnique;
type SimpleTypePrimitive = SimpleTypeLiteral | SimpleTypeString | SimpleTypeNumber | SimpleTypeBoolean | SimpleTypeBigInt | SimpleTypeNull | SimpleTypeUndefined | SimpleTypeESSymbol;
export type SimpleType = SimpleTypePrimitive | SimpleTypeNonPrimitive | SimpleTypeVoid | SimpleTypeNever | SimpleTypeAny | SimpleTypeFunction | SimpleTypeMethod | SimpleTypeUnknown | SimpleTypeTuple | SimpleTypeArray | SimpleTypeInterface | SimpleTypeClass | SimpleTypeObject | SimpleTypeUnion | SimpleTypeIntersection | SimpleTypeEnum | SimpleTypeEnumMember | SimpleTypeAlias | SimpleTypeGenericArguments | SimpleTypeGenericParameter | SimpleTypeDate | SimpleTypePromise;
export declare const SIMPLE_TYPES: {
    readonly STRING: SimpleTypeString;
    readonly STRING_LITERAL: SimpleTypeStringLiteral;
    readonly NUMBER: SimpleTypeNumber;
    readonly BOOLEAN: SimpleTypeBoolean;
    readonly NULL: SimpleTypeNull;
    readonly UNDEFINED: SimpleTypeUndefined;
    readonly ANY: SimpleTypeAny;
    readonly ARRAY: SimpleTypeArray;
    readonly OBJECT: SimpleTypeObject;
};
export declare function or<T>(list: T[], match: (arg: T, i: number) => boolean): boolean;
export declare function and<T>(list: T[], match: (arg: T, i: number) => boolean): boolean;
export declare function isTypeChecker(obj: unknown): obj is TypeChecker;
export declare function isProgram(obj: unknown): obj is Program;
export declare function isNode(obj: unknown): obj is Node;
export declare function isSimpleTypeLiteral(type: SimpleType): type is SimpleTypeLiteral;
export declare function isSimpleType(type: unknown): type is SimpleType;
export declare function isSimpleTypePrimitive(type: SimpleType): type is SimpleTypePrimitive;
export declare function setTypescriptModule(ts: typeof tsModule): void;
export declare function getTypescriptModule(): typeof tsModule;
interface ToSimpleTypeOptions {
    eager?: boolean;
    cache?: WeakMap<Type, SimpleType>;
}
export declare function toSimpleType(type: Type | Node | SimpleType, checker?: TypeChecker, options?: ToSimpleTypeOptions): SimpleType;
interface SimpleTypeBaseOptions {
}
export interface SimpleTypeComparisonOptions extends SimpleTypeBaseOptions {
    strict?: boolean;
    strictNullChecks?: boolean;
    strictFunctionTypes?: boolean;
    noStrictGenericChecks?: boolean;
    isAssignable?: (typeA: SimpleType, typeB: SimpleType, options: SimpleTypeComparisonOptions) => boolean | undefined | void;
    debug?: boolean;
    debugLog?: (text: string) => void;
    cache?: WeakMap<SimpleType, WeakMap<SimpleType, boolean>>;
    maxDepth?: number;
    maxOps?: number;
}
export declare const DEFAULT_GENERIC_PARAMETER_TYPE: SimpleTypeUnknown;
export declare function validateType(type: SimpleType, callback: (simpleType: SimpleType) => boolean | undefined | void): boolean;
export declare function resolveType(simpleType: SimpleType, parameterMap?: Map<string, SimpleType>): Exclude<SimpleType, SimpleTypeGenericParameter | SimpleTypeGenericArguments>;
export declare function extendTypeParameterMap(genericType: SimpleTypeGenericArguments, existingMap: Map<string, SimpleType>): Map<string, SimpleType>;
interface SimpleTypeKindComparisonOptions extends SimpleTypeBaseOptions {
    matchAny?: boolean;
}
export declare function isAssignableToSimpleTypeKind(type: SimpleType, kind: SimpleTypeKind | SimpleTypeKind[], options?: SimpleTypeKindComparisonOptions): boolean;
export declare function isAssignableToSimpleTypeKind(type: Type | SimpleType, kind: SimpleTypeKind | SimpleTypeKind[], checker: TypeChecker, options?: SimpleTypeKindComparisonOptions): boolean;
export declare function typeToString(simpleType: SimpleType): string;
export declare function typeToString(type: SimpleType | Type, checker: TypeChecker): string;
export declare function simpleTypeToString(type: SimpleType): string;
export {};
//# sourceMappingURL=simple-type.d.ts.map