import { TransformerFunction } from "../transformer-function.js";
/**
 * Transforms results to json.
 * @param results
 * @param program
 * @param config
 */
export declare const debugJsonTransformer: TransformerFunction;
//# sourceMappingURL=debug-json-transformer.d.ts.map