import { TransformerFunction } from "../transformer-function.js";
/**
 * Transforms the component results to markdown
 * @param results
 * @param program
 * @param config
 */
export declare const markdownTransformer: TransformerFunction;
//# sourceMappingURL=markdown-transformer.d.ts.map