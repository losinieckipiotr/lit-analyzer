import { AnalyzerVisitContext } from "./analyzer-visit-context.js";
import { AnalyzerOptions } from "./types/analyzer-options.js";
/**
 * Creates an "analyzer visit context" based on some options
 * @param options
 */
export declare function makeContextFromConfig(options: AnalyzerOptions): AnalyzerVisitContext;
//# sourceMappingURL=make-context-from-config.d.ts.map