import { AnalyzerVisitContext } from "../../analyzer-visit-context.js";
import { ComponentMember } from "../../types/features/component-member.js";
/**
 * Merges multiple members based on priority
 * @param members
 * @param context
 */
export declare function mergeMembers(members: ComponentMember[], context: AnalyzerVisitContext): ComponentMember[];
//# sourceMappingURL=merge-members.d.ts.map