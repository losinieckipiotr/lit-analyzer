import { AnalyzerVisitContext } from "../../analyzer-visit-context.js";
import { ComponentFeatureCollection } from "../../flavors/analyzer-flavor.js";
/**
 * Merges all features in collections of features
 * @param collection
 * @param context
 */
export declare function mergeFeatures(collection: ComponentFeatureCollection | ComponentFeatureCollection[], context: AnalyzerVisitContext): ComponentFeatureCollection;
//# sourceMappingURL=merge-features.d.ts.map