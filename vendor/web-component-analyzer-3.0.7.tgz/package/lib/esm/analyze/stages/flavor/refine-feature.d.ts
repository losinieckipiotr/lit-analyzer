import { AnalyzerVisitContext } from "../../analyzer-visit-context.js";
import { AnalyzerDeclarationVisitContext, FeatureVisitReturnTypeMap } from "../../flavors/analyzer-flavor.js";
import { ComponentFeature, ComponentFeatureBase } from "../../types/features/component-feature.js";
export type RefineFeatureEmitMap = {
    [K in ComponentFeature]: (result: FeatureVisitReturnTypeMap[K]) => void;
};
/**
 * Uses flavors to refine a feature
 * Flavors can also remove a feature
 * @param featureKind
 * @param value
 * @param context
 * @param emitMap
 */
export declare function refineFeature<FeatureKind extends ComponentFeature, ValueType extends ComponentFeatureBase = FeatureVisitReturnTypeMap[FeatureKind]>(featureKind: FeatureKind, value: ValueType | ValueType[], context: AnalyzerVisitContext | AnalyzerDeclarationVisitContext, emitMap: Partial<RefineFeatureEmitMap>): void;
//# sourceMappingURL=refine-feature.d.ts.map