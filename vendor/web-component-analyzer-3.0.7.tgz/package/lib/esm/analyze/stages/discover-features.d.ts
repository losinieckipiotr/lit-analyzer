import { Node } from "typescript";
import { AnalyzerDeclarationVisitContext, ComponentFeatureCollection } from "../flavors/analyzer-flavor.js";
/**
 * Discovers features for a given node using flavors
 * @param node
 * @param context
 */
export declare function discoverFeatures(node: Node, context: AnalyzerDeclarationVisitContext): ComponentFeatureCollection;
//# sourceMappingURL=discover-features.d.ts.map