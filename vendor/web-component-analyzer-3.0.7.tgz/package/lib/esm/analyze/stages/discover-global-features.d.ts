import { Node } from "typescript";
import { AnalyzerVisitContext } from "../analyzer-visit-context.js";
import { ComponentFeatures } from "../types/component-declaration.js";
/**
 * Discover all global features using flavors
 * @param node
 * @param context
 */
export declare function discoverGlobalFeatures(node: Node, context: AnalyzerVisitContext): ComponentFeatures;
//# sourceMappingURL=discover-global-features.d.ts.map