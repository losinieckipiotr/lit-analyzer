import { Node } from "typescript";
import { AnalyzerVisitContext } from "../../analyzer-visit-context.js";
import { ComponentEvent } from "../../types/features/component-event.js";
/**
 * Discovers events dispatched
 * @param node
 * @param context
 */
export declare function discoverEvents(node: Node, context: AnalyzerVisitContext): ComponentEvent[] | undefined;
//# sourceMappingURL=discover-events.d.ts.map