import { AnalyzerFlavor } from "../analyzer-flavor.js";
import { discoverDefinitions } from "./discover-definitions.js";
import { discoverEvents } from "./discover-events.js";
import { discoverInheritance } from "./discover-inheritance.js";
import { discoverMembers } from "./discover-members.js";
import { discoverMethods } from "./discover-methods.js";
import { excludeNode } from "./exclude-node.js";
/**
 * A flavor that discovers using standard custom element rules
 */
export declare class CustomElementFlavor implements AnalyzerFlavor {
    excludeNode: typeof excludeNode;
    discoverDefinitions: typeof discoverDefinitions;
    discoverFeatures: {
        member: typeof discoverMembers;
        event: typeof discoverEvents;
        method: typeof discoverMethods;
    };
    discoverGlobalFeatures: Partial<import("../analyzer-flavor.js").FeatureDiscoverVisitMap<import("../../analyzer-visit-context.js").AnalyzerVisitContext>> | undefined;
    discoverInheritance: typeof discoverInheritance;
}
//# sourceMappingURL=custom-element-flavor.d.ts.map