import { AnalyzerFlavor } from "../analyzer-flavor.js";
/**
 * Discovers global feature defined on "HTMLElementEventMap" or "HTMLElement"
 */
export declare const discoverGlobalFeatures: AnalyzerFlavor["discoverGlobalFeatures"];
//# sourceMappingURL=discover-global-features.d.ts.map