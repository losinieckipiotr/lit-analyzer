import { AnalyzerFlavor } from "../analyzer-flavor.js";
import { discoverDefinitions } from "./discover-definitions.js";
import { discoverMembers } from "./discover-members.js";
import { excludeNode } from "./exclude-node.js";
/**
 * Flavors for analyzing LitElement related features: https://lit-element.polymer-project.org/
 */
export declare class LitElementFlavor implements AnalyzerFlavor {
    excludeNode: typeof excludeNode;
    discoverDefinitions: typeof discoverDefinitions;
    discoverFeatures: {
        member: typeof discoverMembers;
    };
    refineFeature: Partial<import("../analyzer-flavor.js").FeatureRefineVisitMap> | undefined;
}
//# sourceMappingURL=lit-element-flavor.d.ts.map