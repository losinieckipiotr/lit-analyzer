import { AnalyzerFlavor } from "../analyzer-flavor.js";
export declare const refineFeature: AnalyzerFlavor["refineFeature"];
//# sourceMappingURL=refine-feature.d.ts.map