import { Node } from "typescript";
import { AnalyzerVisitContext } from "../../analyzer-visit-context.js";
export declare function excludeNode(node: Node, context: AnalyzerVisitContext): boolean | undefined;
//# sourceMappingURL=exclude-node.d.ts.map