import { AnalyzerVisitContext } from "../../analyzer-visit-context.js";
import { FeatureDiscoverVisitMap } from "../analyzer-flavor.js";
export declare const discoverFeatures: Partial<FeatureDiscoverVisitMap<AnalyzerVisitContext>>;
//# sourceMappingURL=discover-features.d.ts.map