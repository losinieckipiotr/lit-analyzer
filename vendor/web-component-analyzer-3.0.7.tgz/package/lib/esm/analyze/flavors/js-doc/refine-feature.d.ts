import { AnalyzerFlavor } from "../analyzer-flavor.js";
/**
 * Refines features by looking at the jsdoc tags on the feature
 */
export declare const refineFeature: AnalyzerFlavor["refineFeature"];
//# sourceMappingURL=refine-feature.d.ts.map