import { AnalyzerFlavor } from "../analyzer-flavor.js";
import { discoverDefinitions } from "./discover-definitions.js";
import { refineDeclaration } from "./refine-declaration.js";
/**
 * Flavors for analyzing jsdoc related features
 */
export declare class JsDocFlavor implements AnalyzerFlavor {
    discoverDefinitions: typeof discoverDefinitions;
    discoverFeatures: Partial<import("../analyzer-flavor.js").FeatureDiscoverVisitMap<import("../../analyzer-visit-context.js").AnalyzerVisitContext>>;
    discoverGlobalFeatures: Partial<import("../analyzer-flavor.js").FeatureDiscoverVisitMap<import("../../analyzer-visit-context.js").AnalyzerVisitContext>> | undefined;
    refineFeature: Partial<import("../analyzer-flavor.js").FeatureRefineVisitMap> | undefined;
    refineDeclaration: typeof refineDeclaration;
}
//# sourceMappingURL=js-doc-flavor.d.ts.map