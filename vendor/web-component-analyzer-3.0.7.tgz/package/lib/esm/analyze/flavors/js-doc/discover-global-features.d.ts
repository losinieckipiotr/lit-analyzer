import { AnalyzerFlavor } from "../analyzer-flavor.js";
export declare const discoverGlobalFeatures: AnalyzerFlavor["discoverGlobalFeatures"];
//# sourceMappingURL=discover-global-features.d.ts.map