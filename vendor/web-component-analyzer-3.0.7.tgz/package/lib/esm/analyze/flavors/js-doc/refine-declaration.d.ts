import { AnalyzerVisitContext } from "../../analyzer-visit-context.js";
import { ComponentDeclaration } from "../../types/component-declaration.js";
/**
 * Refines a component declaration by using jsdoc tags
 * @param declaration
 * @param context
 */
export declare function refineDeclaration(declaration: ComponentDeclaration, context: AnalyzerVisitContext): ComponentDeclaration | undefined;
//# sourceMappingURL=refine-declaration.d.ts.map