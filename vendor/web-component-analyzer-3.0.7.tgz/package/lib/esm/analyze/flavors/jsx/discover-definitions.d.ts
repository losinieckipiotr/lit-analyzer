import { Node } from "typescript";
import { AnalyzerVisitContext } from "../../analyzer-visit-context.js";
import { DefinitionNodeResult } from "../analyzer-flavor.js";
/**
 * Discovers element definitions in "IntrinsicElements"
 * @param node
 * @param context
 */
export declare function discoverDefinitions(node: Node, context: AnalyzerVisitContext): DefinitionNodeResult[] | undefined;
//# sourceMappingURL=discover-definitions.d.ts.map