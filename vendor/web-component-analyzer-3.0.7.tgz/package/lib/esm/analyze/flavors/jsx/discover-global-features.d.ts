import { AnalyzerFlavor } from "../analyzer-flavor.js";
/**
 * Discovers members declared on "IntrinsicAttributes"
 */
export declare const discoverGlobalFeatures: AnalyzerFlavor["discoverGlobalFeatures"];
//# sourceMappingURL=discover-global-features.d.ts.map