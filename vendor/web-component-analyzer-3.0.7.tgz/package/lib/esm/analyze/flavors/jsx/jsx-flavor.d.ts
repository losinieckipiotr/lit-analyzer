import { AnalyzerFlavor } from "../analyzer-flavor.js";
import { discoverDefinitions } from "./discover-definitions.js";
/**
 * Flavors for analyzing jsx related features
 */
export declare class JSXFlavor implements AnalyzerFlavor {
    discoverDefinitions: typeof discoverDefinitions;
    discoverGlobalFeatures: Partial<import("../analyzer-flavor.js").FeatureDiscoverVisitMap<import("../../analyzer-visit-context.js").AnalyzerVisitContext>> | undefined;
}
//# sourceMappingURL=jsx-flavor.d.ts.map