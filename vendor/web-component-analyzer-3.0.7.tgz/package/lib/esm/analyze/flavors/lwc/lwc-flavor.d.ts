import { AnalyzerFlavor } from "../analyzer-flavor.js";
import { discoverDefinitions } from "./discover-definitions.js";
import { discoverMembers } from "./discover-members.js";
/**
 * Flavors for analyzing LWC related features: https://lwc.dev/
 */
export declare class LwcFlavor implements AnalyzerFlavor {
    discoverDefinitions: typeof discoverDefinitions;
    discoverFeatures: {
        member: typeof discoverMembers;
    };
    refineFeature: Partial<import("../analyzer-flavor.js").FeatureRefineVisitMap> | undefined;
}
//# sourceMappingURL=lwc-flavor.d.ts.map