import { SourceFile } from "typescript";
import { AnalyzerOptions } from "./types/analyzer-options.js";
import { AnalyzerResult } from "./types/analyzer-result.js";
/**
 * Analyzes all components in a source file.
 * @param sourceFile
 * @param options
 */
export declare function analyzeSourceFile(sourceFile: SourceFile, options: AnalyzerOptions): AnalyzerResult;
//# sourceMappingURL=analyze-source-file.d.ts.map