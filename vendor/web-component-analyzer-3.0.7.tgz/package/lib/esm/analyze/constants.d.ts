import { Node } from "typescript";
import { AnalyzerFlavor, ComponentFeatureCollection } from "./flavors/analyzer-flavor.js";
import { ComponentDeclaration } from "./types/component-declaration.js";
export declare const VERSION = "<@VERSION@>";
export declare const DEFAULT_FLAVORS: AnalyzerFlavor[];
export declare const DEFAULT_FEATURE_COLLECTION_CACHE: WeakMap<Node, ComponentFeatureCollection>;
export declare const DEFAULT_COMPONENT_DECLARATION_CACHE: WeakMap<Node, ComponentDeclaration>;
//# sourceMappingURL=constants.d.ts.map