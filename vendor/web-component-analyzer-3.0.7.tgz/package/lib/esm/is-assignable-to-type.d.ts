import { Node, Program, Type, TypeChecker } from "typescript";
import { SimpleType, SimpleTypeComparisonOptions } from "./simple-type.js";
/**
 * Returns if typeB is assignable to typeA.
 * @param typeA Type A
 * @param typeB Type B
 * @param config
 */
export declare function isAssignableToSimpleType(typeA: SimpleType, typeB: SimpleType, config?: SimpleTypeComparisonOptions): boolean;
export declare function isAssignableToType(typeA: SimpleType, typeB: SimpleType, options?: SimpleTypeComparisonOptions): boolean;
export declare function isAssignableToType(typeA: SimpleType | Type | Node, typeB: SimpleType | Type | Node, checker: TypeChecker | Program, options?: SimpleTypeComparisonOptions): boolean;
export declare function isAssignableToType(typeA: Type | Node, typeB: Type | Node, checker: TypeChecker | Program, options?: SimpleTypeComparisonOptions): boolean;
export declare function isAssignableToType(typeA: Type | Node | SimpleType, typeB: Type | Node | SimpleType, checker: Program | TypeChecker, options?: SimpleTypeComparisonOptions): boolean;
export declare function isAssignableToPrimitiveType(type: SimpleType): boolean;
export declare function isAssignableToPrimitiveType(type: Type | SimpleType, checker: TypeChecker): boolean;
//# sourceMappingURL=is-assignable-to-type.d.ts.map